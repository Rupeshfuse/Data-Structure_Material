package com.doublylinkedlist.exam;

public interface ReverseIterator<T> {

	public boolean hasPreviuos();
	public T previous();
	
}
