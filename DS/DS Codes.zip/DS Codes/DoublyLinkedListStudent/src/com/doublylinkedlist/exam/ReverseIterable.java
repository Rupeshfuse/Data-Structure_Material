package com.doublylinkedlist.exam;

public interface ReverseIterable<T> {
	
	public ReverseIterator<T> reverseIterator() ;

}
